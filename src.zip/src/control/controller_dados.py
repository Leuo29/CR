class ControllerDados:
    def __init__(self, arquivo_csv: str):
        from leitor_csv import LeitorCSV  # assumindo que você tenha essa classe
        self.leitor = LeitorCSV(arquivo_csv)
        self.matriculas = []
        self.alunos = {}
        self.cursos = {}
        self.disciplinas = {}

    def processar_dados(self):
        dados = self.leitor.ler_dados()  

        for linha in dados:
            # Ex.: linha = {'aluno': '123', 'nome_aluno': 'Leo', 'curso': 'CC', 'disciplina': 'POO', 'carga': 64, 'nota': 85}

            # Cria/recupera curso
            codigo_curso = linha['curso']
            if codigo_curso not in self.cursos:
                self.cursos[codigo_curso] = Curso(codigo_curso)
            curso = self.cursos[codigo_curso]

            # Cria/recupera disciplina
            codigo_disciplina = linha['disciplina']
            if codigo_disciplina not in self.disciplinas:
                self.disciplinas[codigo_disciplina] = Disciplina(codigo_disciplina, linha['disciplina'], linha['carga'])
            disciplina = self.disciplinas[codigo_disciplina]

            # Cria/recupera aluno
            matricula_aluno = linha['aluno']
            if matricula_aluno not in self.alunos:
                self.alunos[matricula_aluno] = Aluno(matricula_aluno, linha['nome_aluno'])
            aluno = self.alunos[matricula_aluno]

            # Cria matrícula
            matricula = Matricula(matricula_aluno, curso)
            aluno.adicionar_matricula(matricula)
            curso.adicionar_matricula(matricula)
            self.matriculas.append(matricula)

            # Cria nota
            nota = Nota(disciplina, linha['nota'])
            matricula.adicionar_nota(nota)

            # Calcula CR da matrícula
            matricula.calcular_cr()

    def get_matriculas(self):
        return self.matriculas
